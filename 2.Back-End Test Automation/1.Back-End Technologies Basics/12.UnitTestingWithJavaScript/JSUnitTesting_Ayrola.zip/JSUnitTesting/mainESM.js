import * as myUtils from "./functionsESM.mjs"

console.log(myUtils.add(5, 5));
console.log(myUtils.substract(10, 5));