const {add, substract} = require("./functionsCommonJs.js");

console.log(add(5, 5));
console.log(substract(10, 5));